<?php $titre = 'Mon Blog' ?>

<?php ob_start(); ?>
	<p>Une erreur est survenue: <?= $msgErreur ?></p>
<?php $contenu = ob_get_clean(); ?>

<?php require_once 'gabarit.php'; ?>